<?php

include_once "modelos/ConstantesConexion.php";
include_once "controladores/ControladorPrincipal.php";



$control=new ControladorPrincipal();




?>