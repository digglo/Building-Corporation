<?php

define("BASE","proyecto");//se define una constante para la base, de ahora en adelante BASE
//define("SERVIDOR", "127.0.0.1"); //se define una constante para el servidor, de ahora en adelante SERVIDOR
define("SERVIDOR", "127.0.0.1");//se define una constante para el servidor, de ahora en adelante SERVIDOR
define("USUARIO_BD", "root"); 
define("CONTRASENIA_BD", "");


define("PATH", $_SERVER['DOCUMENT_ROOT']."/BUILDING-CORPORATION/");

