<?php


include_once "../modelos/ConstantesConexion.php";
include_once PATH ."/modelos/ConBdMysql.php";


$con=new ConBdMySql(BASE,SERVIDOR,USUARIO_BD,CONTRASENIA_BD);



?>